import { Browser, expect, Page } from "@playwright/test";
import { Iyoutube } from '../interface/youtube';
import { cancionAleatoria, canciones } from '../data/cancion';

export class paginaYoutube implements Iyoutube {

    private page: Page;
    constructor(page: Page){
        this.page = page;
    }

    async ir(): Promise<void> {
        await this.page.goto('https://www.youtube.com/')
        await this.page.waitForTimeout(3000);
    }


    async enterCancion(canciones: string): Promise<void> {
        await this.page.click('input#search');
        await this.page.fill('//input[@id="search"]', canciones)
    }


    async buscar(): Promise<void> {
        await this.page.click('//button[@id="search-icon-legacy"]');
        await this.page.waitForSelector('ytd-video-renderer');
    }

    async buscarCancion(canciones: string): Promise<void> {
        await this.enterCancion(canciones);
        await this.buscar();
    }

    async seleccionarV(): Promise<void> {
        const listaVideos = await this.page.$$('ytd-video-renderer');
        const index = Math.floor(Math.random()* listaVideos.length)
        const videoRandom = listaVideos[index];
        await this.page.waitForTimeout(3000);

        const listaTituloVideo = await videoRandom.$('a#video-title');
        const seleccionTituloVideo = await listaTituloVideo?.textContent();

        console.log(seleccionTituloVideo);

        await videoRandom.click();

        await expect(seleccionTituloVideo).toContain(canciones);
    }
}