import { test, expect } from '@playwright/test';
import { paginaYoutube } from '../pageObjects/pagina';
import { Iyoutube } from '../interface/youtube';
import { cancionAleatoria, canciones } from '../data/cancion';


test.describe('Suite', ()=>{
    test('Buscar cancion', async ({page})=>{
        const youtube:Iyoutube = new paginaYoutube(page);
        await youtube.ir();
        await youtube.enterCancion(cancionAleatoria.nombreCancion);
        await youtube.buscar();
        await youtube.seleccionarV();
        });
  });
 