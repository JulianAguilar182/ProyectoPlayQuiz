import { Page } from '@playwright/test';

export interface Iyoutube {
    ir(): Promise<void>;
    enterCancion(song:string): Promise<void>;
    buscar(): Promise<void>;
    buscarCancion(song:string): Promise<void>;
    seleccionarV(): Promise<void>;
}