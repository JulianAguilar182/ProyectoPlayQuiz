export const canciones = [
    {nombreCancion: 'mi sueño, willie colon'},
    {nombreCancion: 'cut me off, blink-182'},
    {nombreCancion: 'hot dog, limp bizkit'},
    {nombreCancion: 'sic, slipknot'}
]

function buscarCanciones(canciones: {nombreCancion: string}[]): {nombreCancion: string}{
    const index = Math.floor(Math.random() * canciones.length);
    return canciones[index];
}

export const cancionAleatoria = buscarCanciones(canciones);

